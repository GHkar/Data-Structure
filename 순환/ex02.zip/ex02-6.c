#include<stdio.h>

#define MAX_ARRAY 10
int array[MAX_ARRAY] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
void reverse(int n)
{
	if (n < MAX_ARRAY) 
	{
	
		printf("%d ", array[(MAX_ARRAY -n-1)]);
		return reverse(n+1);
		
	}

	
}

int main(void)
{
	reverse(0);
	return 0;
}
