#include<stdio.h>

#define MAX_ARRAY 10
int array[MAX_ARRAY] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
void reverse()
{
	int i;
	for (i = 1; i <= MAX_ARRAY; i++)
		printf("%d ", array[10 - i]);
}
	
int main(void)
{
	reverse();
	return 0;
}
